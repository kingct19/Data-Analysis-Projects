
def box_string(string):
    return string

print (box_string("Coding is fun"))
print (box_string("Python is my favorite"))
print (box_string("have a great day"))
