def main():
    x = 1
    y = 3.4
    print(x, y)
    change_us(x, y)
    print(x, y)

def change_us(a, b):
    a = 0
    b = 0
    print(a, b)

main()
