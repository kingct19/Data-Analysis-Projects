

def time_ten(number):
    return 10*number

print(time_ten(5))
print(time_ten(6))
print(time_ten(8))